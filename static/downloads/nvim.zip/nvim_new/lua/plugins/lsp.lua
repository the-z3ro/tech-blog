-- ============================================================
-- LSP CONFIGURATION
-- nvim-lspconfig provides default server metadata (filetypes,
-- binary paths). Mason installs the actual server binaries.
-- Servers are configured via vim.lsp.config() and enabled via
-- vim.lsp.enable() — the native Neovim 0.11 API.
-- Keymaps are registered on LspAttach per-buffer.
-- ============================================================
return {
	"neovim/nvim-lspconfig",
	event = { "BufReadPre", "BufNewFile" }, -- lazy: load when a file is opened
	dependencies = {
		"williamboman/mason.nvim",
		{ "williamboman/mason-lspconfig.nvim", version = "v1.*" },

		-- LSP loading indicator (shows "lua_ls: loading..." in corner)
		{
			"j-hui/fidget.nvim",
			tag = "v1.4.0",
			opts = {
				progress = {
					display = { done_icon = "✓" },
				},
				notification = {
					window = { winblend = 0 },
				},
			},
		},
	},
	config = function()
		-- ── LSP Attach: keymaps that only work inside a file with an LSP ──
		vim.api.nvim_create_autocmd("LspAttach", {
			group = vim.api.nvim_create_augroup("lsp-attach", { clear = true }),
			callback = function(event)
				local map = function(keys, func, desc)
					vim.keymap.set("n", keys, func, { buffer = event.buf, desc = "LSP: " .. desc })
				end

				-- Go-to
				map("gd", require("telescope.builtin").lsp_definitions, "Goto Definition")
				map("gr", require("telescope.builtin").lsp_references, "Goto References")
				map("gI", require("telescope.builtin").lsp_implementations, "Goto Implementation")
				map("gD", vim.lsp.buf.declaration, "Goto Declaration")

				-- Info
				map("K", vim.lsp.buf.hover, "Hover Docs")
				map("<leader>D", require("telescope.builtin").lsp_type_definitions, "Type Definition")
				map("<leader>ds", require("telescope.builtin").lsp_document_symbols, "Document Symbols")
				map("<leader>ws", require("telescope.builtin").lsp_dynamic_workspace_symbols, "Workspace Symbols")

				-- Actions
				map("<leader>rn", vim.lsp.buf.rename, "Rename Symbol")
				map("<leader>ca", vim.lsp.buf.code_action, "Code Action")

				-- Workspace folders
				map("<leader>wa", vim.lsp.buf.add_workspace_folder, "Add Workspace Folder")
				map("<leader>wr", vim.lsp.buf.remove_workspace_folder, "Remove Workspace Folder")
				map("<leader>wl", function()
					print(vim.inspect(vim.lsp.buf.list_workspace_folders()))
				end, "List Workspace Folders")

				-- Auto-highlight references under cursor (if server supports it)
				local client = vim.lsp.get_client_by_id(event.data.client_id)
				if client and client.server_capabilities.documentHighlightProvider then
					vim.api.nvim_create_autocmd({ "CursorHold", "CursorHoldI" }, {
						buffer = event.buf,
						callback = vim.lsp.buf.document_highlight,
					})
					vim.api.nvim_create_autocmd({ "CursorMoved", "CursorMovedI" }, {
						buffer = event.buf,
						callback = vim.lsp.buf.clear_references,
					})
				end
			end,
		})

		-- Merge LSP capabilities with nvim-cmp's extra capabilities
		local capabilities = vim.lsp.protocol.make_client_capabilities()
		capabilities = vim.tbl_deep_extend("force", capabilities, require("cmp_nvim_lsp").default_capabilities())

		-- ── Server Definitions ────────────────────────────────────
		-- Only languages you actually use. Add more from:
		-- https://github.com/neovim/nvim-lspconfig/blob/master/doc/configs.md
		local servers = {
			-- Web
			html = { filetypes = { "html", "twig", "hbs" } },
			cssls = {},
			tailwindcss = {},
			ts_ls = {}, -- TypeScript / JavaScript

			-- Systems & DSA (C / C++)
			clangd = {},

			-- Python (ruff handles both linting AND formatting)
			ruff = {
				commands = {
					RuffAutofix = {
						function()
							vim.lsp.buf.execute_command({
								command = "ruff.applyAutofix",
								arguments = { { uri = vim.uri_from_bufnr(0) } },
							})
						end,
						description = "Ruff: Fix all auto-fixable problems",
					},
					RuffOrganizeImports = {
						function()
							vim.lsp.buf.execute_command({
								command = "ruff.applyOrganizeImports",
								arguments = { { uri = vim.uri_from_bufnr(0) } },
							})
						end,
						description = "Ruff: Organize imports",
					},
				},
			},

			-- Lua (for editing this Neovim config)
			lua_ls = {
				settings = {
					Lua = {
						runtime = { version = "LuaJIT" },
						workspace = {
							checkThirdParty = false,
							library = { "${3rd}/luv/library", unpack(vim.api.nvim_get_runtime_file("", true)) },
						},
						completion = { callSnippet = "Replace" },
						telemetry = { enable = false },
						diagnostics = { disable = { "missing-fields" } },
					},
				},
			},

			-- Docker (since you use Docker)
			dockerls = {},
			docker_compose_language_service = {},

			-- Config files
			jsonls = {},
			yamlls = {},
			bashls = {},

			-- Rust
			rust_analyzer = {
				settings = { -- FIXED: was missing the "settings" wrapper key
					["rust-analyzer"] = {
						cargo = { features = "all" },
						checkOnSave = true,
						check = { command = "clippy" },
					},
				},
			},
		}

		-- ── Mason Setup ───────────────────────────────────────────
		-- Mason manages tool installations. NOTE: ensure_installed does NOT
		-- belong in mason.setup() — it belongs in mason-lspconfig/mason-null-ls.
		require("mason").setup({
			ui = {
				border = "rounded",
				icons = {
					package_installed = "✓",
					package_pending = "➜",
					package_uninstalled = "✗",
				},
			},
		})

		-- ── Global capabilities ───────────────────────────────────
		-- Set cmp capabilities for ALL servers in one place using the
		-- new Neovim 0.11 native API (avoids the deprecated lspconfig call).
		vim.lsp.config("*", { capabilities = capabilities })

		-- ── Mason-LSPConfig Setup ─────────────────────────────────
		-- auto-installs servers and enables them via the native 0.11 API.
		require("mason-lspconfig").setup({
			ensure_installed = vim.tbl_keys(servers),
			handlers = {
				function(server_name)
					local server = servers[server_name] or {}
					-- Merge any per-server capabilities on top of the global ones
					if server.capabilities then
						server.capabilities = vim.tbl_deep_extend(
							"force",
							capabilities,
							server.capabilities
						)
					end
					-- vim.lsp.config: set server options (replaces lspconfig[x].setup())
					-- vim.lsp.enable: tell Neovim to start this server for matching files
					vim.lsp.config(server_name, server)
					vim.lsp.enable(server_name)
				end,
			},
		})
	end,
}
