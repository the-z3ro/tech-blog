-- ============================================================
-- TREESITTER — Syntax highlighting, indentation, text objects
-- ============================================================
return {
	"nvim-treesitter/nvim-treesitter",
	event = { "BufReadPre", "BufNewFile" },
	build = ":TSUpdate",
	dependencies = {
		"nvim-treesitter/nvim-treesitter-textobjects",
	},
	config = function()
		require("nvim-treesitter.configs").setup({
			ensure_installed = {
				-- Languages you actively use
				"lua",
				"python",
				"javascript",
				"typescript",
				"tsx",
				"c",
				"cpp",
				"rust",
				"go",
				"java",

				-- Web
				"html",
				"css",

				-- Config & data formats
				"json",
				"yaml",
				"toml",
				"markdown",
				"markdown_inline",

				-- Shell & scripting
				"bash",

				-- Neovim internals
				"vim",
				"vimdoc",
				"regex",

				-- Docker
				"dockerfile",

				-- Build systems
				"make",
				"cmake",

				-- Other
				"gitignore",
				"sql",
				"groovy",
				"graphql",
			},
			auto_install = true,
			highlight = { enable = true },
			indent = { enable = true },

			-- Ctrl-Space to expand selection incrementally
			incremental_selection = {
				enable = true,
				keymaps = {
					init_selection = "<C-space>",
					node_incremental = "<C-space>",
					scope_incremental = "<C-s>",
					node_decremental = "<M-space>",
				},
			},

			-- Text objects: select, move, swap by code structure
			textobjects = {
				select = {
					enable = true,
					lookahead = true,
					keymaps = {
						["aa"] = "@parameter.outer", -- around argument/parameter
						["ia"] = "@parameter.inner", -- inner argument
						["af"] = "@function.outer",  -- around function
						["if"] = "@function.inner",  -- inner function body
						["ac"] = "@class.outer",     -- around class
						["ic"] = "@class.inner",     -- inner class body
					},
				},
				move = {
					enable = true,
					set_jumps = true,
					goto_next_start = {
						["]m"] = "@function.outer",
						["]]"] = "@class.outer",
					},
					goto_next_end = {
						["]M"] = "@function.outer",
						["]["] = "@class.outer",
					},
					goto_previous_start = {
						["[m"] = "@function.outer",
						["[["] = "@class.outer",
					},
					goto_previous_end = {
						["[M"] = "@function.outer",
						["[]"] = "@class.outer",
					},
				},
				swap = {
					enable = true,
					swap_next = {
						["<leader>a"] = "@parameter.inner", -- swap argument with next
					},
					swap_previous = {
						["<leader>A"] = "@parameter.inner", -- swap argument with previous
					},
				},
			},
		})

		-- Extra filetype associations
		vim.filetype.add({ extension = { tf = "terraform" } })
		vim.filetype.add({ extension = { tfvars = "terraform" } })
		vim.filetype.add({ extension = { pipeline = "groovy" } })
		vim.filetype.add({ extension = { multibranch = "groovy" } })
	end,
}
