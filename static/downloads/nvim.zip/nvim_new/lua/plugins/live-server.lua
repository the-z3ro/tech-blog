return {
	"barrett-ruth/live-server.nvim",
	build = "npm install -g live-server",
	cmd = { "LiveServerStart", "LiveServerStop" }, -- lazy: load only when you run these commands
	config = function()
		require("live-server").setup({
			quiet = false,
			no_browser = false,
			extensions = { "html", "css", "js" },
			port = 8080,
		})

		vim.keymap.set("n", "<leader>ls", ":LiveServerStart<CR>", { noremap = true, silent = true, desc = "Live Server Start" })
		vim.keymap.set("n", "<leader>le", ":LiveServerStop<CR>", { noremap = true, silent = true, desc = "Live Server Stop" })
	end,
}
