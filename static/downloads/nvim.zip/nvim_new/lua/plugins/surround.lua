-- ============================================================
-- NVIM-SURROUND — Add, change, delete surrounding pairs
--
-- Add:    ys{motion}{char}    e.g. ysiw" wraps word in quotes
--         yss{char}           surrounds entire line
-- Change: cs{from}{to}        e.g. cs"' changes " to '
--         cst{tag}            changes surrounding HTML tag
-- Delete: ds{char}            e.g. ds" removes surrounding "
--         dst                 removes surrounding HTML tag
--
-- Visual: S{char}             surround selection
-- ============================================================
return {
	"kylechui/nvim-surround",
	version = "*",
	event = { "BufReadPre", "BufNewFile" },
	config = true, -- uses default config, no customization needed
}
