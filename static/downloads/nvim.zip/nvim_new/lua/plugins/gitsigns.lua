-- ============================================================
-- GITSIGNS — Inline git diff in the sign column
-- Shows added/changed/deleted lines with colored markers.
-- Also provides hunk staging, blame, and diff viewing.
-- ============================================================
return {
	"lewis6991/gitsigns.nvim",
	event = { "BufReadPre", "BufNewFile" }, -- lazy: load when a file opens
	opts = {
		signs = {
			add = { text = "▎" },
			change = { text = "▎" },
			delete = { text = "" },
			topdelete = { text = "" },
			changedelete = { text = "▎" },
			untracked = { text = "▎" },
		},
		signs_staged = {
			add = { text = "▎" },
			change = { text = "▎" },
			delete = { text = "" },
			topdelete = { text = "" },
			changedelete = { text = "▎" },
		},
		on_attach = function(bufnr)
			local gs = package.loaded.gitsigns

			local function map(mode, l, r, desc)
				vim.keymap.set(mode, l, r, { buffer = bufnr, desc = desc })
			end

			-- Navigate between hunks (changed sections)
			map("n", "]h", gs.next_hunk, "Next git hunk")
			map("n", "[h", gs.prev_hunk, "Prev git hunk")

			-- Stage / reset hunks
			map("n", "<leader>hs", gs.stage_hunk, "Stage hunk")
			map("n", "<leader>hr", gs.reset_hunk, "Reset hunk")
			map("v", "<leader>hs", function()
				gs.stage_hunk({ vim.fn.line("."), vim.fn.line("v") })
			end, "Stage selected hunk")
			map("v", "<leader>hr", function()
				gs.reset_hunk({ vim.fn.line("."), vim.fn.line("v") })
			end, "Reset selected hunk")

			-- Stage / reset whole buffer
			map("n", "<leader>hS", gs.stage_buffer, "Stage buffer")
			map("n", "<leader>hR", gs.reset_buffer, "Reset buffer")
			map("n", "<leader>hu", gs.undo_stage_hunk, "Undo stage hunk")

			-- Preview & blame
			map("n", "<leader>hp", gs.preview_hunk, "Preview hunk")
			map("n", "<leader>hb", function()
				gs.blame_line({ full = true })
			end, "Blame line (full)")
			map("n", "<leader>tb", gs.toggle_current_line_blame, "Toggle line blame")

			-- Diff
			map("n", "<leader>hd", gs.diffthis, "Diff this file")
			map("n", "<leader>hD", function()
				gs.diffthis("~")
			end, "Diff against last commit")

			-- Toggle deleted lines preview
			map("n", "<leader>td", gs.toggle_deleted, "Toggle deleted lines")
		end,
	},
}
