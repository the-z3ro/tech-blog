-- ============================================================
-- MISC PLUGINS — Small plugins with minimal config
-- ============================================================
return {
	-- tmux & split window navigation (works with your tmux setup)
	{
		"christoomey/vim-tmux-navigator",
	},

	-- Auto-close HTML/JSX tags when typing
	{
		"windwp/nvim-ts-autotag",
		event = { "BufReadPre", "BufNewFile" },
	},

	-- Detect tabstop and shiftwidth from existing file style
	{
		"tpope/vim-sleuth",
	},

	-- Git integration: :G status, :G diff, :G commit, etc.
	{
		"tpope/vim-fugitive",
	},

	-- GitHub integration for fugitive (:GBrowse opens file on GitHub)
	{
		"tpope/vim-rhubarb",
	},

	-- which-key: shows keybinding hints after pressing leader
	{
		"folke/which-key.nvim",
		event = "VeryLazy",
		config = function()
			local wk = require("which-key")
			wk.setup({})

			-- Register group labels so the leader menu is organized
			wk.add({
				{ "<leader>s", group = "search (telescope)" },
				{ "<leader>g", group = "git (telescope/fugitive)" },
				{ "<leader>h", group = "git hunks (gitsigns)" },
				{ "<leader>H", group = "harpoon" },
				{ "<leader>d", group = "diagnostics" },
				{ "<leader>w", group = "workspace / lsp" },
				{ "<leader>t", group = "tabs" },
				{ "g", group = "goto (lsp)" },
			})
		end,
	},

	-- Auto-close brackets, quotes, parens
	{
		"windwp/nvim-autopairs",
		event = "InsertEnter",
		config = true,
	},

	-- Highlight TODO, FIXME, NOTE, HACK comments
	{
		"folke/todo-comments.nvim",
		event = "VimEnter",
		dependencies = { "nvim-lua/plenary.nvim" },
		opts = { signs = false },
	},

	-- Color highlighter — shows #hex, rgb(), and tailwind colors inline
	-- NOTE: using the maintained NvChad fork (norcalli's original is archived)
	{
		"NvChad/nvim-colorizer.lua",
		event = { "BufReadPre", "BufNewFile" },
		opts = {
			user_default_options = {
				tailwind = true, -- highlight Tailwind class names
				mode = "background",
			},
		},
	},

	-- NOTE: nvim-comment is intentionally removed.
	-- Neovim 0.10+ has native gc/gcc commenting built in — no plugin needed.
}
