-- ============================================================
-- TELESCOPE — Fuzzy finder for files, grep, LSP, git, and more
-- ============================================================
return {
	"nvim-telescope/telescope.nvim",
	branch = "0.1.x",
	cmd = "Telescope", -- also loads on these keys:
	keys = {
		"<leader>sf",
		"<leader>sg",
		"<leader>sw",
		"<leader>sb",
		"<leader>sh",
		"<leader>sm",
		"<leader>sd",
		"<leader>sr",
		"<leader>s.",
		"<leader>?",
		"<leader>/",
		"<leader><leader>",
	},
	dependencies = {
		"nvim-lua/plenary.nvim",
		{
			"nvim-telescope/telescope-fzf-native.nvim",
			build = "make",
			cond = function()
				return vim.fn.executable("make") == 1
			end,
		},
		"nvim-telescope/telescope-ui-select.nvim",
		"nvim-tree/nvim-web-devicons",
	},
	config = function()
		local telescope = require("telescope")
		local actions = require("telescope.actions")
		local builtin = require("telescope.builtin")

		telescope.setup({
			defaults = {
				mappings = {
					i = {
						["<C-k>"] = actions.move_selection_previous,
						["<C-j>"] = actions.move_selection_next,
						["<C-l>"] = actions.select_default,
					},
					n = {
						["q"] = actions.close,
					},
				},
			},
			pickers = {
				find_files = {
					file_ignore_patterns = { "node_modules", ".git", ".venv" },
					hidden = true,
				},
				buffers = {
					initial_mode = "normal",
					sort_lastused = true,
					mappings = {
						n = {
							["d"] = actions.delete_buffer,
							["l"] = actions.select_default,
						},
					},
				},
				live_grep = {
					file_ignore_patterns = { "node_modules", ".git", ".venv" },
					additional_args = function()
						return { "--hidden" }
					end,
				},
			},
			extensions = {
				["ui-select"] = {
					require("telescope.themes").get_dropdown(),
				},
			},
		})

		pcall(telescope.load_extension, "fzf")
		pcall(telescope.load_extension, "ui-select")

		-- ── Keymaps ───────────────────────────────────────────────
		-- Files
		vim.keymap.set("n", "<leader>sf", builtin.find_files, { desc = "Search Files" })
		vim.keymap.set("n", "<leader>sg", builtin.live_grep, { desc = "Search by Grep" })
		vim.keymap.set("n", "<leader>sw", builtin.grep_string, { desc = "Search current Word" })
		vim.keymap.set("n", "<leader>s.", builtin.oldfiles, { desc = "Search Recent Files" })
		vim.keymap.set("n", "<leader>?", builtin.oldfiles, { desc = "Recently opened files" })

		-- Buffers & marks
		vim.keymap.set("n", "<leader>sb", builtin.buffers, { desc = "Search Buffers" })
		vim.keymap.set("n", "<leader><leader>", builtin.buffers, { desc = "Find existing buffers" })
		vim.keymap.set("n", "<leader>sm", builtin.marks, { desc = "Search Marks" })

		-- Help & diagnostics
		vim.keymap.set("n", "<leader>sh", builtin.help_tags, { desc = "Search Help" })
		vim.keymap.set("n", "<leader>sd", builtin.diagnostics, { desc = "Search Diagnostics" })
		vim.keymap.set("n", "<leader>sr", builtin.resume, { desc = "Search Resume (last)" })

		-- Git
		vim.keymap.set("n", "<leader>gf", builtin.git_files, { desc = "Search Git Files" })
		vim.keymap.set("n", "<leader>gc", builtin.git_commits, { desc = "Search Git Commits" })
		vim.keymap.set("n", "<leader>gcf", builtin.git_bcommits, { desc = "Search Git Commits (file)" })
		vim.keymap.set("n", "<leader>gb", builtin.git_branches, { desc = "Search Git Branches" })
		vim.keymap.set("n", "<leader>gs", builtin.git_status, { desc = "Search Git Status" })

		-- LSP symbols
		vim.keymap.set("n", "<leader>sds", function()
			builtin.lsp_document_symbols({
				symbols = { "Class", "Function", "Method", "Constructor", "Interface", "Module", "Property" },
			})
		end, { desc = "Search Document Symbols" })

		-- Search inside current buffer (fuzzy)
		vim.keymap.set("n", "<leader>/", function()
			builtin.current_buffer_fuzzy_find(require("telescope.themes").get_dropdown({ previewer = false }))
		end, { desc = "Fuzzy search in buffer" })

		-- Search across open files
		vim.keymap.set("n", "<leader>s/", function()
			builtin.live_grep({
				grep_open_files = true,
				prompt_title = "Live Grep in Open Files",
			})
		end, { desc = "Search in open files" })
	end,
}
