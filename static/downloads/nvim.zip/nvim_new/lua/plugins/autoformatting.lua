-- ============================================================
-- AUTOFORMATTING & LINTING (none-ls)
-- Formatters run automatically on save via BufWritePre.
-- ============================================================
return {
	"nvimtools/none-ls.nvim",
	event = { "BufReadPre", "BufNewFile" },
	dependencies = {
		"nvimtools/none-ls-extras.nvim",
		"jayp0521/mason-null-ls.nvim",
	},
	config = function()
		local null_ls = require("null-ls")
		local formatting = null_ls.builtins.formatting
		local diagnostics = null_ls.builtins.diagnostics

		-- These tools will be auto-installed by mason-null-ls
		require("mason-null-ls").setup({
			ensure_installed = {
				"checkmake", -- Makefile linter
				"prettier", -- JS/TS/HTML/CSS/JSON/YAML/Markdown formatter
				"stylua", -- Lua formatter
				"eslint_d", -- JS/TS linter (fast daemon)
				"shfmt", -- Shell formatter
				"ruff", -- Python formatter & linter
				"clang-format", -- C / C++ formatter
			},
			automatic_installation = true,
		})

		local sources = {
			-- Linters
			diagnostics.checkmake,
			require("none-ls.diagnostics.eslint_d"), -- JS/TS linting

			-- Formatters
			formatting.prettier.with({
				filetypes = { "html", "css", "json", "yaml", "markdown", "javascript", "typescript", "javascriptreact", "typescriptreact" },
			}),
			formatting.stylua, -- Lua
			formatting.shfmt.with({ args = { "-i", "4" } }), -- Shell
			formatting.clang_format.with({ -- C / C++
				filetypes = { "c", "cpp", "h", "hpp" },
			}),
			require("none-ls.formatting.ruff").with({ extra_args = { "--extend-select", "I" } }), -- Python
			require("none-ls.formatting.ruff_format"), -- Python format pass
		}

		-- Auto-format on save
		local augroup = vim.api.nvim_create_augroup("LspFormatting", {})
		null_ls.setup({
			sources = sources,
			on_attach = function(client, bufnr)
				if client.supports_method("textDocument/formatting") then
					vim.api.nvim_clear_autocmds({ group = augroup, buffer = bufnr })
					vim.api.nvim_create_autocmd("BufWritePre", {
						group = augroup,
						buffer = bufnr,
						callback = function()
							vim.lsp.buf.format({ async = false })
						end,
					})
				end
			end,
		})
	end,
}
