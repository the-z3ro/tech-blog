-- ============================================================
-- AUTOCOMPLETION + SNIPPETS
-- LuaSnip is managed here (not as a separate plugin) to avoid
-- key conflicts between cmp and standalone luasnip mappings.
-- ============================================================
return {
	"hrsh7th/nvim-cmp",
	event = "InsertEnter", -- lazy load: only when you start typing
	dependencies = {
		-- Snippet engine
		{
			"L3MON4D3/LuaSnip",
			build = (function()
				if vim.fn.has("win32") == 1 or vim.fn.executable("make") == 0 then
					return
				end
				return "make install_jsregexp"
			end)(),
		},
		"saadparwaiz1/cmp_luasnip",

		-- Completion sources
		"hrsh7th/cmp-nvim-lsp",
		"hrsh7th/cmp-buffer",
		"hrsh7th/cmp-path",

		-- Pre-built snippet collection (React, JS, Python, etc.)
		"rafamadriz/friendly-snippets",
	},
	config = function()
		local cmp = require("cmp")
		local luasnip = require("luasnip")

		-- Load friendly-snippets (VS Code style snippet packs)
		require("luasnip.loaders.from_vscode").lazy_load()

		luasnip.config.setup({
			history = true,
			updateevents = "TextChanged,TextChangedI",
		})

		-- ── Custom Snippets ────────────────────────────────────────
		local s = luasnip.snippet
		local t = luasnip.text_node
		local i = luasnip.insert_node

		-- Lua: type "func" and expand
		luasnip.add_snippets("lua", {
			s("func", {
				t("function "),
				i(1, "name"),
				t("()"),
				i(0),
			}),
		})

		-- C++: type "cppm" and expand (competitive programming template)
		luasnip.add_snippets("cpp", {
			s("cppm", {
				t({
					"#include <bits/stdc++.h>",
					"using namespace std;",
					"",
					"int main(){",
					"",
				}),
				i(1, 'cout<<"Coded by Jarvis";'),
				t({
					"",
					"    return 0;",
					"}",
				}),
			}),
		})

		-- HTML: type "!" and expand
		luasnip.add_snippets("html", {
			s("!", {
				t({
					"<!DOCTYPE html>",
					'<html lang="en">',
					"<head>",
					'    <meta charset="UTF-8">',
					'    <meta name="viewport" content="width=device-width, initial-scale=1.0">',
					"    <title>",
				}),
				i(1, "My Website"),
				t({
					"</title>",
					"</head>",
					"<body>",
					"    ",
				}),
				i(2),
				t({
					"",
					"</body>",
					"</html>",
				}),
			}),
		})

		-- ── Kind Icons ────────────────────────────────────────────
		local kind_icons = {
			Text = "󰉿",
			Method = "m",
			Function = "󰊕",
			Constructor = "",
			Field = "",
			Variable = "󰆧",
			Class = "󰌗",
			Interface = "",
			Module = "",
			Property = "",
			Unit = "",
			Value = "󰎠",
			Enum = "",
			Keyword = "󰌋",
			Snippet = "",
			Color = "󰏘",
			File = "󰈙",
			Reference = "",
			Folder = "󰉋",
			EnumMember = "",
			Constant = "󰇽",
			Struct = "",
			Event = "",
			Operator = "󰆕",
			TypeParameter = "󰊄",
		}

		-- ── CMP Setup ─────────────────────────────────────────────
		cmp.setup({
			snippet = {
				expand = function(args)
					luasnip.lsp_expand(args.body)
				end,
			},
			completion = { completeopt = "menu,menuone,noinsert" },
			mapping = cmp.mapping.preset.insert({
				-- Navigate completion menu
				["<C-j>"] = cmp.mapping.select_next_item(),
				["<C-k>"] = cmp.mapping.select_prev_item(),

				-- Confirm selection
				["<CR>"] = cmp.mapping.confirm({ select = true }),

				-- Manually trigger completion
				["<C-c>"] = cmp.mapping.complete({}),

				-- Scroll docs popup
				["<C-u>"] = cmp.mapping.scroll_docs(-4),
				["<C-d>"] = cmp.mapping.scroll_docs(4),

				-- Tab: next item or expand/jump snippet forward
				["<Tab>"] = cmp.mapping(function(fallback)
					if cmp.visible() then
						cmp.select_next_item()
					elseif luasnip.expand_or_locally_jumpable() then
						luasnip.expand_or_jump()
					else
						fallback()
					end
				end, { "i", "s" }),

				-- Shift+Tab: prev item or jump snippet backward
				["<S-Tab>"] = cmp.mapping(function(fallback)
					if cmp.visible() then
						cmp.select_prev_item()
					elseif luasnip.locally_jumpable(-1) then
						luasnip.jump(-1)
					else
						fallback()
					end
				end, { "i", "s" }),

				-- Ctrl-l / Ctrl-h: jump between snippet placeholders
				["<C-l>"] = cmp.mapping(function()
					if luasnip.expand_or_locally_jumpable() then
						luasnip.expand_or_jump()
					end
				end, { "i", "s" }),
				["<C-h>"] = cmp.mapping(function()
					if luasnip.locally_jumpable(-1) then
						luasnip.jump(-1)
					end
				end, { "i", "s" }),
			}),
			sources = {
				{ name = "nvim_lsp" },
				{ name = "luasnip" },
				{ name = "buffer" },
				{ name = "path" },
			},
			formatting = {
				fields = { "kind", "abbr", "menu" },
				format = function(entry, vim_item)
					vim_item.kind = string.format("%s", kind_icons[vim_item.kind])
					vim_item.menu = ({
						nvim_lsp = "[LSP]",
						luasnip = "[Snippet]",
						buffer = "[Buffer]",
						path = "[Path]",
					})[entry.source.name]
					return vim_item
				end,
			},
		})
	end,
}
