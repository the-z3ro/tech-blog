return {
	{
		"sainnhe/everforest",
		lazy = false,
		priority = 1000,
		config = function()
			vim.g.everforest_background = "hard"
			vim.g.everforest_transparent_background = 1
			vim.g.everforest_enable_italic = 1
			vim.g.everforest_disable_italic_comment = 0
			vim.g.everforest_diagnostic_text_highlight = 1
			vim.g.everforest_diagnostic_line_highlight = 1
			vim.g.everforest_diagnostic_virtual_text = "colored"
			vim.g.everforest_ui_contrast = "low"
			vim.g.everforest_current_word = "bold"
			vim.g.everforest_float_style = "dim"
			vim.g.everforest_show_eob = 1
			vim.g.everforest_dim_inactive_windows = 0
			vim.cmd("colorscheme everforest")
		end,
	},
}
