-- ============================================================
-- TOGGLETERM — Floating terminal + Lazygit
-- BUG FIXED: lazygit function was defined as local "lazygit_toggle"
-- but keymap called "_lazygit_toggle". Now uses global naming correctly.
-- ============================================================
return {
	"akinsho/toggleterm.nvim",
	keys = { "<C-t>", "<leader>lg" }, -- lazy load: only when these keys are pressed
	config = function()
		require("toggleterm").setup({
			size = 10,
			open_mapping = [[<C-t>]],
			hide_numbers = true,
			shade_terminals = true,
			shading_factor = 2,
			start_in_insert = true,
			insert_mappings = true,
			terminal_mappings = true,
			persist_size = true,
			direction = "float",
			close_on_exit = false,
			float_opts = {
				border = "curved",
				width = 90,
				height = 25,
				winblend = 3,
			},
		})

		-- Lazygit integration
		-- FIXED: must be a global function (prefixed with _) for the keymap to reach it
		local Terminal = require("toggleterm.terminal").Terminal
		local lazygit = Terminal:new({
			cmd = "lazygit",
			hidden = true,
			direction = "float",
			float_opts = {
				border = "curved",
				width = math.floor(vim.o.columns * 0.9),
				height = math.floor(vim.o.lines * 0.85),
			},
		})

		function _lazygit_toggle()
			lazygit:toggle()
		end

		vim.keymap.set("n", "<leader>lg", "<cmd>lua _lazygit_toggle()<CR>", {
			noremap = true,
			silent = true,
			desc = "Toggle Lazygit",
		})
	end,
}
