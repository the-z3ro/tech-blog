-- ============================================================
-- HARPOON 2 — Instant jumps between your 4 most-used files
-- Add a file: <leader>Ha
-- Open menu:  <leader>Hh
-- Jump to files: <leader>H1/2/3/4
-- ============================================================
return {
	"ThePrimeagen/harpoon",
	branch = "harpoon2",
	event = "VeryLazy",
	dependencies = { "nvim-lua/plenary.nvim" },
	config = function()
		local harpoon = require("harpoon")
		harpoon:setup({
			settings = {
				save_on_toggle = true,
				sync_on_ui_close = true,
			},
		})

		-- Add current file to harpoon list
		vim.keymap.set("n", "<leader>Ha", function()
			harpoon:list():add()
		end, { desc = "Harpoon: Add file" })

		-- Open the harpoon menu (navigate and reorder)
		vim.keymap.set("n", "<leader>Hh", function()
			harpoon.ui:toggle_quick_menu(harpoon:list())
		end, { desc = "Harpoon: Menu" })

		-- Jump directly to file slots 1–4
		vim.keymap.set("n", "<leader>H1", function()
			harpoon:list():select(1)
		end, { desc = "Harpoon: File 1" })
		vim.keymap.set("n", "<leader>H2", function()
			harpoon:list():select(2)
		end, { desc = "Harpoon: File 2" })
		vim.keymap.set("n", "<leader>H3", function()
			harpoon:list():select(3)
		end, { desc = "Harpoon: File 3" })
		vim.keymap.set("n", "<leader>H4", function()
			harpoon:list():select(4)
		end, { desc = "Harpoon: File 4" })

		-- Cycle through harpoon list without opening the menu
		vim.keymap.set("n", "<leader>Hn", function()
			harpoon:list():next()
		end, { desc = "Harpoon: Next file" })
		vim.keymap.set("n", "<leader>Hp", function()
			harpoon:list():prev()
		end, { desc = "Harpoon: Prev file" })
	end,
}
