-- ============================================================
-- CODE RUNNER
-- Runs the current file in a terminal split.
-- BUG FIXED: removed duplicate toggleterm.setup() that was
-- overwriting the configuration in toggleterm.lua.
-- ============================================================
return {
	"CRAG666/code_runner.nvim",
	dependencies = "nvim-lua/plenary.nvim",
	cmd = "RunCode", -- lazy load: only when :RunCode is called
	keys = { { "<leader>r", "<cmd>RunCode<CR>", desc = "Run current file" } },
	config = function()
		require("code_runner").setup({
			-- Opens output in a horizontal terminal split via toggleterm
			term = {
				toggleterm = true,
				position = "horizontal",
				size = 15,
			},

			filetype = {
				python = "python3 -u",
				javascript = "node",
				java = "javac % && java %:r",
				go = "go run",
				rust = "cargo run",
				sh = "bash",
				lua = "lua",

				-- C: compile with gcc then run
				c = function()
					local file_path = vim.fn.expand("%:p")
					local file_dir = vim.fn.expand("%:p:h")
					local exe_name = vim.fn.expand("%:t:r")
					local exe_path = file_dir .. "/" .. exe_name
					return "cd "
						.. vim.fn.shellescape(file_dir)
						.. " && gcc -std=c11 -Wall -Wextra -O2 "
						.. vim.fn.shellescape(file_path)
						.. " -o "
						.. vim.fn.shellescape(exe_path)
						.. " && "
						.. vim.fn.shellescape(exe_path)
				end,

				-- C++: compile with g++ then run
				cpp = function()
					local file_path = vim.fn.expand("%:p")
					local file_dir = vim.fn.expand("%:p:h")
					local exe_name = vim.fn.expand("%:t:r")
					local exe_path = file_dir .. "/" .. exe_name
					return "cd "
						.. vim.fn.shellescape(file_dir)
						.. " && g++ -std=c++17 -Wall -Wextra -O2 "
						.. vim.fn.shellescape(file_path)
						.. " -o "
						.. vim.fn.shellescape(exe_path)
						.. " && "
						.. vim.fn.shellescape(exe_path)
				end,
			},
		})
	end,
}
