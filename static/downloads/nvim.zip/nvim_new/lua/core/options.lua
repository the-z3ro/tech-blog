-- ============================================================
-- CORE OPTIONS
-- ============================================================

local opt = vim.opt

-- Line numbers
opt.number = true
opt.relativenumber = true
opt.numberwidth = 4

-- Cursor & Scrolling
opt.scrolloff = 8
opt.sidescrolloff = 8
opt.cursorline = false

-- Indentation
opt.tabstop = 4
opt.shiftwidth = 4
opt.softtabstop = 4
opt.expandtab = true
opt.smartindent = true
opt.autoindent = true

-- Wrapping
opt.wrap = false
opt.linebreak = true
opt.breakindent = true
opt.whichwrap = "bs<>[]hl"

-- Search
opt.hlsearch = false
opt.ignorecase = true
opt.smartcase = true
opt.inccommand = "split" -- live preview of :s substitution in a split window

-- Splits
opt.splitbelow = true
opt.splitright = true

-- Files & History
opt.undofile = true
opt.swapfile = false
opt.backup = false
opt.writebackup = false

-- Appearance
opt.termguicolors = true
opt.showmode = false
opt.signcolumn = "yes"
opt.pumheight = 10
opt.conceallevel = 0
opt.showtabline = 2
opt.laststatus = 3 -- single global statusline (cleaner with lualine)

-- Timing
opt.updatetime = 250
opt.timeoutlen = 300

-- Completion
opt.completeopt = "menuone,noselect"

-- Encoding & Misc
opt.fileencoding = "utf-8"
opt.cmdheight = 1
opt.mouse = "a"
opt.clipboard = "unnamedplus"
opt.backspace = "indent,eol,start"

-- Folding (treesitter-based, all folds open by default)
opt.foldmethod = "expr"
opt.foldexpr = "nvim_treesitter#foldexpr()"
opt.foldenable = false -- don't fold on open
opt.foldlevel = 99

-- Invisible characters (shows trailing spaces, tabs)
opt.list = true
opt.listchars = { trail = "·", tab = "» ", nbsp = "+" }

-- Adjustments
opt.shortmess:append("c")
opt.iskeyword:append("-")
opt.formatoptions:remove({ "c", "r", "o" })
opt.runtimepath:remove("/usr/share/vim/vimfiles")
