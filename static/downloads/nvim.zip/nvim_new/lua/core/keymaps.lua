-- ============================================================
-- CORE KEYMAPS
-- ============================================================

vim.g.mapleader = " "
vim.g.maplocalleader = " "

local opts = { noremap = true, silent = true }

-- Disable space in normal/visual (it's the leader key)
vim.keymap.set({ "n", "v" }, "<Space>", "<Nop>", { silent = true })

-- ── Navigation ────────────────────────────────────────────────
-- Handle wrapped lines (gj/gk for visual lines, j/k for real lines with count)
vim.keymap.set("n", "k", "v:count == 0 ? 'gk' : 'k'", { expr = true, silent = true })
vim.keymap.set("n", "j", "v:count == 0 ? 'gj' : 'j'", { expr = true, silent = true })

-- Scroll and center (Ctrl-d / Ctrl-u both now scroll AND center)
vim.keymap.set("n", "<C-d>", "<C-d>zz", opts)
vim.keymap.set("n", "<C-u>", "<C-u>zz", opts)

-- Keep search results centered
vim.keymap.set("n", "n", "nzzzv", opts)
vim.keymap.set("n", "N", "Nzzzv", opts)

-- Clear search highlights
vim.keymap.set("n", "<Esc>", ":noh<CR>", opts)

-- ── Escape ────────────────────────────────────────────────────
vim.keymap.set("i", "jk", "<ESC>", opts)
vim.keymap.set("i", "kj", "<ESC>", opts)

-- ── File Operations ───────────────────────────────────────────
vim.keymap.set("n", "<C-s>", "<cmd>w<CR>", opts)
vim.keymap.set("n", "<leader>sn", "<cmd>noautocmd w<CR>", vim.tbl_extend("force", opts, { desc = "Save without format" }))
vim.keymap.set("n", "<C-q>", "<cmd>q<CR>", opts)

-- ── Editing ───────────────────────────────────────────────────
-- Delete single char without polluting yank register
vim.keymap.set("n", "x", '"_x', opts)

-- Duplicate line (Alt+d to avoid colliding with <C-d> scroll)
vim.keymap.set("n", "<A-d>", "yyp", opts)
vim.keymap.set("v", "<A-d>", "y'>p", opts)

-- Move lines up/down
vim.keymap.set("n", "<A-j>", ":m .+1<CR>==", opts)
vim.keymap.set("n", "<A-k>", ":m .-2<CR>==", opts)
vim.keymap.set("v", "<A-j>", ":m '>+1<CR>gv=gv", opts)
vim.keymap.set("v", "<A-k>", ":m '<-2<CR>gv=gv", opts)

-- Stay in indent mode after indenting in visual
vim.keymap.set("v", "<", "<gv", opts)
vim.keymap.set("v", ">", ">gv", opts)

-- Paste without overwriting yank register
vim.keymap.set("v", "p", '"_dP', opts)

-- Yank to system clipboard
vim.keymap.set({ "n", "v" }, "<leader>y", [["+y]], { desc = "Yank to clipboard" })
vim.keymap.set("n", "<leader>Y", [["+Y]], { desc = "Yank line to clipboard" })

-- Replace word under cursor (interactive — use . to repeat on next match)
vim.keymap.set("n", "<leader>j", "*``cgn", opts)

-- Increment / decrement numbers
vim.keymap.set("n", "<leader>+", "<C-a>", { desc = "Increment number" })
vim.keymap.set("n", "<leader>-", "<C-x>", { desc = "Decrement number" })

-- Toggle line wrap
vim.keymap.set("n", "<leader>lw", "<cmd>set wrap!<CR>", { desc = "Toggle line wrap" })

-- ── Buffers ───────────────────────────────────────────────────
vim.keymap.set("n", "<Tab>", ":bnext<CR>", opts)
vim.keymap.set("n", "<S-Tab>", ":bprevious<CR>", opts)
vim.keymap.set("n", "<leader>x", ":Bdelete!<CR>", { desc = "Close buffer" })
vim.keymap.set("n", "<leader>b", "<cmd>enew<CR>", { desc = "New buffer" })

-- ── Window Splits ─────────────────────────────────────────────
vim.keymap.set("n", "<leader>v", "<C-w>v", { desc = "Split vertical" })
vim.keymap.set("n", "<leader>hs", "<C-w>s", { desc = "Split horizontal" })
vim.keymap.set("n", "<leader>se", "<C-w>=", { desc = "Equalize splits" })
vim.keymap.set("n", "<leader>xs", ":close<CR>", { desc = "Close split" })

-- Navigate between splits (works with vim-tmux-navigator for tmux panes too)
vim.keymap.set("n", "<C-k>", ":wincmd k<CR>", opts)
vim.keymap.set("n", "<C-j>", ":wincmd j<CR>", opts)
vim.keymap.set("n", "<C-h>", ":wincmd h<CR>", opts)
vim.keymap.set("n", "<C-l>", ":wincmd l<CR>", opts)

-- Resize splits with arrow keys
vim.keymap.set("n", "<Up>", ":resize -2<CR>", opts)
vim.keymap.set("n", "<Down>", ":resize +2<CR>", opts)
vim.keymap.set("n", "<Left>", ":vertical resize -2<CR>", opts)
vim.keymap.set("n", "<Right>", ":vertical resize +2<CR>", opts)

-- ── Tabs ──────────────────────────────────────────────────────
vim.keymap.set("n", "<leader>to", ":tabnew<CR>", { desc = "New tab" })
vim.keymap.set("n", "<leader>tx", ":tabclose<CR>", { desc = "Close tab" })
vim.keymap.set("n", "<leader>tn", ":tabn<CR>", { desc = "Next tab" })
vim.keymap.set("n", "<leader>tp", ":tabp<CR>", { desc = "Previous tab" })

-- ── Diagnostics ───────────────────────────────────────────────
vim.keymap.set("n", "[d", vim.diagnostic.goto_prev, { desc = "Previous diagnostic" })
vim.keymap.set("n", "]d", vim.diagnostic.goto_next, { desc = "Next diagnostic" })
vim.keymap.set("n", "<leader>d", vim.diagnostic.open_float, { desc = "Diagnostic float" })
vim.keymap.set("n", "<leader>q", vim.diagnostic.setloclist, { desc = "Diagnostics list" })

-- Toggle diagnostics on/off
local diagnostics_active = true
vim.keymap.set("n", "<leader>do", function()
	diagnostics_active = not diagnostics_active
	if diagnostics_active then
		vim.diagnostic.enable(0)
	else
		vim.diagnostic.disable(0)
	end
end, { desc = "Toggle diagnostics" })

-- ── Sessions ──────────────────────────────────────────────────
vim.keymap.set("n", "<leader>ss", ":mksession! .session.vim<CR>", { noremap = true, silent = false, desc = "Save session" })
vim.keymap.set("n", "<leader>sl", ":source .session.vim<CR>", { noremap = true, silent = false, desc = "Load session" })
