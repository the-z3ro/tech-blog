require("core.options")
require("core.keymaps")

-- Bootstrap lazy.nvim
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not vim.loop.fs_stat(lazypath) then
	vim.fn.system({
		"git",
		"clone",
		"--filter=blob:none",
		"https://github.com/folke/lazy.nvim.git",
		"--branch=stable",
		lazypath,
	})
end
vim.opt.rtp:prepend(lazypath)

require("lazy").setup({
	-- UI
	require("plugins.colortheme"),
	require("plugins.alpha"),
	require("plugins.lualine"),
	require("plugins.bufferline"),

	-- Navigation
	require("plugins.neotree"),
	require("plugins.telescope"),
	require("plugins.harpoon"),

	-- Editor
	require("plugins.treesitter"),
	require("plugins.surround"),
	require("plugins.indent-blankline"),

	-- LSP & Completion
	require("plugins.lsp"),
	require("plugins.autocompletion"),
	require("plugins.autoformatting"),

	-- Git
	require("plugins.gitsigns"),

	-- Terminal & Runner
	require("plugins.toggleterm"),
	require("plugins.coderunner"),

	-- Web
	require("plugins.live-server"),

	-- Misc
	require("plugins.misc"),
}, {
	ui = {
		border = "rounded",
	},
	checker = {
		enabled = true,
		notify = false, -- silent update checks
	},
	change_detection = {
		notify = false,
	},
})
